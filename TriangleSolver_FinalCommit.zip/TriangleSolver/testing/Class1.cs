﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using TriangleSolver;
namespace testing
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void TriangleChecker_Input30and30and30_OutputEquilaterTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide=30;
            int secondSide = 30;
            int thirdSide = 30;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide,secondSide,thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input30and30and40_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 40;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input30and30and50_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 50;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
            //Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TriangleChecker_Input30and30and60_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 45;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input30and40and50_OutputScaleneTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 40;
            int thirdSide = 50;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input20and65and50_OutputScaleneTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 20;
            int secondSide = 65;
            int thirdSide = 50;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TriangleChecker_Input22and95and90_OutputScaleneTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 22;
            int secondSide = 95;
            int thirdSide = 90;
            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TriangleChecker_Input50and90and137_OutputScaleneTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 50;
            int secondSide = 90;
            int thirdSide = 137;

            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TriangleChecker_Input88and77and22_OutputScaleneTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 88;
            int secondSide = 77;
            int thirdSide = 22;
            string expected = "Based on all three sides being different, the type of triangle is a SCALENE";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input0and0and10_OutputZeroLenghtTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 0;
            int secondSide = 0;
            int thirdSide = 10;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input0and77and10_OutputZeroLenghtTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 0;
            int secondSide = 77;
            int thirdSide = 10;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input0and5and88_OutputZeroLenghtTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 0;
            int secondSide = 5;
            int thirdSide = 88;

            string expected = "At least one side of your triangle has a zero length and is thus invalid";

            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input10and20and70_OutputInvalidResponse()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 10;
            int secondSide = 20;
            int thirdSide = 70;

            string expected = "Based on the values entered, the triangle is INVALID";
            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input55and17and100_OutputInvalidResponse()
        {
            Triangle triangle = new Triangle();
            int firstSide = 55;
            int secondSide = 17;
            int thirdSide = 100;
            string expected = "Based on the values entered, the triangle is INVALID";

            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input200and1000and7_OutputInvalidResponse()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 200;
            int secondSide = 1000;
            int thirdSide = 7;

            string expected = "Based on the values entered, the triangle is INVALID";
            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
