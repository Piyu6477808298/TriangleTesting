﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using TriangleSolver;
namespace testing
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void TriangleChecker_Input30and30and30_OutputEquilaterTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide=30;
            int secondSide = 30;
            int thirdSide = 30;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide,secondSide,thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


       
    }
}
