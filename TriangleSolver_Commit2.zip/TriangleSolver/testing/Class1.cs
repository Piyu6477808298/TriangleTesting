﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using TriangleSolver;
namespace testing
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void TriangleChecker_Input30and30and30_OutputEquilaterTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide=30;
            int secondSide = 30;
            int thirdSide = 30;

            string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

            // Act
            string actual = triangle.AnalyzeTriangle(firstSide,secondSide,thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


        [Test]
        public void TriangleChecker_Input30and30and40_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 40;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }
        [Test]
        public void TriangleChecker_Input30and30and50_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 50;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
            //Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TriangleChecker_Input30and30and60_OutputIsoscelesTriangle()
        {
            Triangle triangle = new Triangle();
            // Arrange
            int firstSide = 30;
            int secondSide = 30;
            int thirdSide = 45;

            string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

            // Act

            string actual = triangle.AnalyzeTriangle(firstSide, secondSide, thirdSide);

            //Assert
            Assert.AreEqual(expected, actual);
        }


       
    }
}
